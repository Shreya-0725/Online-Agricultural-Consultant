﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Web;
using System.Web.Mvc;
using Online_Agricultural_Consultant.Models;

namespace Online_Agricultural_Consultant.Controllers
{
    public class HomeController : Controller
    {
        Online_Agricultural_Consultant_DBEntities db = new Online_Agricultural_Consultant_DBEntities();
        Random rand = new Random();
        public ActionResult Index()
        {
            ViewData["Articals"] = db.tblArticles.ToList();


            return View();
        }

       

        
        public ActionResult user_registration()
        {
            ViewBag.States = db.tblStates.ToList();
            return View();
        }
        [HttpPost]
        public ActionResult user_registration(tblFarmerDetail obj)
        {

            obj.FarmerId = "FARM" + rand.Next(9999, 1000000);
            obj.Password = GeneratePasswords.generate();
            obj.CreatedDate = DateTime.Now.ToString();
            db.tblFarmerDetails.Add(obj);
            db.SaveChanges();
            TempData["user_registration_msg"] = "Registration Success";
            return RedirectToAction("SuccessPage", new {FramerID=obj.FarmerId, FullName=obj.FirstName,Pass=obj.Password });
        }

        public ActionResult SuccessPage(string FramerID, string FullName, string Pass)
        {
            ViewBag.farmerID = FramerID;
            ViewBag.FullName = FullName;
            ViewBag.Pass = Pass;
            return View();
        }

        #region JsonCode
        public JsonResult getDistrictByStateCode(int statecode)
        {
            var list = db.tblDistricts.Where(a => a.StateCode == statecode).ToList();
            var Result = new { list };
            return Json(list, JsonRequestBehavior.AllowGet);
        }
        #endregion

        #region Dashboard
        public ActionResult Dashboard()
        {
            return View();
        }
        #endregion




        #region Expert Section
        public ActionResult expert_registration()
        {
            ViewBag.States = db.tblStates.ToList();
            return View();
        }
        [HttpPost]
        public ActionResult expert_registration(tblExpertDetail obj, HttpPostedFileBase Image)
        {
            obj.ExpertId= "EXP" + rand.Next(9999, 1000000);
            obj.Password = GeneratePasswords.generate();
            obj.Image = "/ExpertDocuments/" + FIleUpload.UploadImage(Image, "ExpertDocuments");
            obj.CreateDate = DateTime.Now;
            db.tblExpertDetails.Add(obj);
            db.SaveChanges();
            TempData["user_registration_msg"] = "Registration Success";
            return RedirectToAction("SuccessPage", new { FramerID = obj.ExpertId, FullName = obj.FirstName, Pass = obj.Password });

        }
        #endregion
    }
}