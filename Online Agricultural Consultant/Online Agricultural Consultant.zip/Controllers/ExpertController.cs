﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using Online_Agricultural_Consultant.Models;

namespace Online_Agricultural_Consultant.Controllers
{
    public class ExpertController : Controller
    {
        Online_Agricultural_Consultant_DBEntities db = new Online_Agricultural_Consultant_DBEntities();
        #region Index
        public ActionResult Index()
        {
            return View();
        }

        public ActionResult Login(string AdminUserID, string Password)
        {
            if (db.tblExpertDetails.Any(a => a.ExpertId == AdminUserID && a.Password == Password))
            {
                Session["Expert_ID"] = AdminUserID;
                return RedirectToAction("Dashboard");
            }
            TempData["MSG"] = "Invalid AdminID or Password !";
            return RedirectToAction("Dashboard");
        }
        #endregion

        #region ErrorPage
        public ActionResult ErrorPage()
        {
            return View();
        }
        #endregion

        #region Dashboard
        public ActionResult Dashboard()
        {
            if (Session["Expert_ID"] == null)
            {
                TempData["MSG"] = "Session Expired Or Invalid URL ! Login Again. !";
                return RedirectToAction("Index");
            }

            return View();
        }
        #endregion

        #region Logout
        public ActionResult Logout()
        {
            Session.Abandon();
            return RedirectToAction("Index");
        }
        #endregion

        #region Articles
        public ActionResult add_articles()
        {
            if (Session["Expert_ID"] == null)
            {
                TempData["MSG"] = "Session Expired Or Invalid URL ! Login Again. !";
                return RedirectToAction("Index");
            }

            return View();
        }

        [HttpPost]
        public ActionResult add_articles(tblArticle obj)
        {
            if (Session["Expert_ID"] == null)
            {
                TempData["MSG"] = "Session Expired Or Invalid URL ! Login Again. !";
                return RedirectToAction("Index");
            }

            obj.CreatedBy = Session["Expert_ID"].ToString();
            obj.CreationDate = DateTime.Now;
            db.tblArticles.Add(obj);
            db.SaveChanges();
            TempData["article_msg"] = "Article added Successfuly";
            return View();
        }

        public ActionResult view_articles()
        {
            if (Session["Expert_ID"] == null)
            {
                TempData["MSG"] = "Session Expired Or Invalid URL ! Login Again. !";
                return RedirectToAction("Index");
            }
            string id = Session["Expert_ID"].ToString();
            return View(db.tblArticles.Where(a=>a.CreatedBy==id).ToList());
        }
        #endregion

        #region Solve regular Issue
        public ActionResult solve_regular_issue()
        {
            if (Session["Expert_ID"] == null)
            {
                TempData["MSG"] = "Session Expired Or Invalid URL ! Login Again. !";
                return RedirectToAction("Index");
            }
            return View(db.tblRegularIssues.OrderByDescending(a=>a.IssueId).ToList());
        }

        public ActionResult AddSolution(int ID_, string Solution)
        {
            if (Session["Expert_ID"] == null)
            {
                TempData["MSG"] = "Session Expired Or Invalid URL ! Login Again. !";
                return RedirectToAction("Index");
            }
            var data = db.tblRegularIssues.Where(a => a.IssueId == ID_).FirstOrDefault();
            if (data!=null)
            {
                data.Solution = Solution;
                data.SolvedBy= Session["Expert_ID"].ToString();
                data.SolutionDate = DateTime.Now;
                data.ModificationDate = DateTime.Now;
                data.Status = "Solved";
                db.Entry<tblRegularIssue>(data).State = System.Data.Entity.EntityState.Modified;
                db.SaveChanges();
                TempData["mmm"] = "<script>alert('Solution Provide Successfully !!')</script>";
            }
            return RedirectToAction("solve_regular_issue");
        }
        #endregion
        #region view_visit_request
        public ActionResult view_visit_request()
        {
            if (Session["Expert_ID"] == null)
            {
                TempData["MSG"] = "Session Expired Or Invalid URL ! Login Again. !";
                return RedirectToAction("Index");
            }
            var ID_ = Session["Expert_ID"].ToString();
            var data = db.tblSiteVisits.Where(a => a.AssignedAsst == ID_).ToList();
            return View(data);
        }

        public ActionResult ViewDetails_asssign_RTA(int ID)
        {
            if (Session["Expert_ID"] == null)
            {
                TempData["MSG"] = "Session Expired Or Invalid URL ! Login Again. !";
                return RedirectToAction("Index");
            }
            var data = db.tblSiteVisits.Where(a => a.ID == ID).FirstOrDefault();
            return View(data);
        }

        public ActionResult update_RTA(tblSiteVisit obj)
        {
            if (Session["Expert_ID"] == null)
            {
                TempData["MSG"] = "Session Expired Or Invalid URL ! Login Again. !";
                return RedirectToAction("Index");
            }
            var data = db.tblSiteVisits.Where(a => a.ID == obj.ID).FirstOrDefault();
            if (data != null)
            {
                data.VisitDate = obj.VisitDate;
                data.SolutionDate = DateTime.Now;
                data.ModificationDate = DateTime.Now;
                data.VisitIntervalInHrs = obj.VisitIntervalInHrs;
                data.ClosingDate = obj.ClosingDate;
                db.Entry<tblSiteVisit>(data).State = System.Data.Entity.EntityState.Modified;
                db.SaveChanges();
                TempData["MSG__"] = "Data Update Successfully !!";
            }
            return RedirectToAction("ViewDetails_asssign_RTA", new {ID=obj.ID });
        }
        #endregion
    }
}